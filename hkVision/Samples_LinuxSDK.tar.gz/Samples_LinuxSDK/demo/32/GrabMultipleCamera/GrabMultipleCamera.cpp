#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include "MvCameraControl.h"

#define MAX_IMAGE_DATA_SIZE   (40*1024*1024)
#define CAMERA_NUM             2

bool g_bExit = false;

// �ȴ��û�����enter��������ȡ�����������
// wait for user to input enter to stop grabbing or end the sample program
void PressEnterToExit(void)
{
	int c;
	while ( (c = getchar()) != '\n' && c != EOF );
    fprintf( stderr, "\nPress enter to exit.\n");
    while( getchar() != '\n');
	g_bExit = true;
	sleep(1);
}

bool PrintDeviceInfo(MV_CC_DEVICE_INFO* pstMVDevInfo)
{
    if (NULL == pstMVDevInfo)
    {
        printf("%s\n" , "The Pointer of pstMVDevInfoList is NULL!");
        return false;
    }
    if (pstMVDevInfo->nTLayerType == MV_GIGE_DEVICE)
    {
		// ��ӡ��ǰ���ip���û��Զ�������
		// print current ip and user defined name
        printf("%s %x\n" , "nCurrentIp:" , pstMVDevInfo->SpecialInfo.stGigEInfo.nCurrentIp);                   //��ǰIP
        printf("%s %s\n\n" , "chUserDefinedName:" , pstMVDevInfo->SpecialInfo.stGigEInfo.chUserDefinedName);     //�û�������
    }
    else if (pstMVDevInfo->nTLayerType == MV_USB_DEVICE)
    {
        printf("UserDefinedName:%s\n\n", pstMVDevInfo->SpecialInfo.stUsb3VInfo.chUserDefinedName);
    }
    else
    {
        printf("Not support.\n");
    }
    return true;
}

static void* WorkThread(void* pUser)
{
    int nRet = MV_OK;

	MVCC_STRINGVALUE stStringValue = {0};
	char camName[256] = {0};
    nRet = MV_CC_GetStringValue(pUser, "DeviceUserID", &stStringValue);
    if (MV_OK == nRet)
    {
		memcpy(camName, stStringValue.chCurValue, sizeof(stStringValue.chCurValue));
    }
    else
    {
        printf("Get DeviceUserID Failed! nRet = [%x]\n", nRet);
    }

    MV_FRAME_OUT_INFO_EX stImageInfo = {0};
    memset(&stImageInfo, 0, sizeof(MV_FRAME_OUT_INFO_EX));
    unsigned char * pData = (unsigned char *)malloc(sizeof(unsigned char) * MAX_IMAGE_DATA_SIZE);
    unsigned int nDataSize = MAX_IMAGE_DATA_SIZE;
	
    while(1)
    {
        nRet = MV_CC_GetOneFrameTimeout(pUser, pData, nDataSize, &stImageInfo, 1000);
        if (nRet == MV_OK)
        {
			printf("cam[%s]:GetOneFrame, Width[%d], Height[%d], nFrameNum[%d]\n", 
				camName, stImageInfo.nWidth, stImageInfo.nHeight, stImageInfo.nFrameNum);
			if(g_bExit)
			{
				break;
			}
		}
		else
		{
			printf("cam[%s]:Get One Frame failed![%x]\n", camName, nRet);
		}
    }

	return 0;
}

int main()
{
    int nRet = MV_OK;

    void* handle[CAMERA_NUM] = {NULL};

    MV_CC_DEVICE_INFO_LIST stDeviceList;
    memset(&stDeviceList, 0, sizeof(MV_CC_DEVICE_INFO_LIST));

    // ö���豸
	// enum device
    nRet = MV_CC_EnumDevices(MV_GIGE_DEVICE | MV_USB_DEVICE, &stDeviceList);
    if (MV_OK != nRet)
    {
        printf("MV_CC_EnumDevices fail! nRet [%x]\n", nRet);
        return -1;
    }
    unsigned int nIndex = 0;
	int i = 0;
    if (stDeviceList.nDeviceNum > 0)
    {
        for (int i = 0; i < stDeviceList.nDeviceNum; i++)
        {
            printf("[device %d]:\n", i);
            MV_CC_DEVICE_INFO* pDeviceInfo = stDeviceList.pDeviceInfo[i];
            if (NULL == pDeviceInfo)
            {
                break;
            } 
            PrintDeviceInfo(pDeviceInfo);            
        }  
    } 
    else
    {
        printf("Find No Devices!\n");
        return -1;
    }

	for(int j = 0; j < CAMERA_NUM; i++, j++)
	{
		printf("please input camera num\n");
		scanf("%d", &nIndex);
	
		// ѡ���豸���������
		// select device and create handle
		nRet = MV_CC_CreateHandle(&handle[i], stDeviceList.pDeviceInfo[nIndex]);
		if (MV_OK != nRet)
		{
			printf("MV_CC_CreateHandle fail! nRet [%x]\n", nRet);
			i--;
			continue;
		}

		// ���豸
		// open device
		nRet = MV_CC_OpenDevice(handle[i]);
		if (MV_OK != nRet)
		{
			printf("MV_CC_OpenDevice fail! nRet [%x]\n", nRet);
			MV_CC_DestroyHandle(handle[i]);
			handle[i] = NULL;
			i--;
			continue;
		}
	}

	int nCameraCount = i;
	for(int i = 0; i < nCameraCount; i++)
	{
		// ���ô���ģʽΪoff
		// set trigger mode as off
		nRet = MV_CC_SetEnumValue(handle[i], "TriggerMode", MV_TRIGGER_MODE_OFF);
		if (MV_OK != nRet)
		{
			printf("Cam[%d]: MV_CC_SetTriggerMode fail! nRet [%x]\n", i, nRet);
		}

		// ��ʼȡ��
		// start grab image
		nRet = MV_CC_StartGrabbing(handle[i]);
		if (MV_OK != nRet)
		{
			printf("Cam[%d]: MV_CC_StartGrabbing fail! nRet [%x]\n",i, nRet);
			return -1;
		}

		pthread_t nThreadID;
		nRet = pthread_create(&nThreadID, NULL ,WorkThread , handle[i]);
		if (nRet != 0)
		{
			printf("Cam[%d]: thread create failed.ret = %d\n",i, nRet);
			return -1;
		}
	}
	
	PressEnterToExit();
	
	for(int i = 0; i < nCameraCount; i++)
	{
		// ֹͣȡ��
		// end grab image
		nRet = MV_CC_StopGrabbing(handle[i]);
		if (MV_OK != nRet)
		{
			printf("MV_CC_StopGrabbing fail! nRet [%x]\n", nRet);
			return -1;
		}

		// �ر��豸
		// close device
		nRet = MV_CC_CloseDevice(handle[i]);
		if (MV_OK != nRet)
		{
			printf("MV_CC_CloseDevice fail! nRet [%x]\n", nRet);
			return -1;
		}

	    // ���پ��
		// destroy handle
		nRet = MV_CC_DestroyHandle(handle[i]);
		if (MV_OK != nRet)
		{
			printf("MV_CC_DestroyHandle fail! nRet [%x]\n", nRet);
			return -1;
		}
	}

	printf("exit\n");
    return 0;
}
